1. Did i collaborate with anyone? No. Individual study.
2. Reference:
[1] https://learnopengl.org;
[2] https://github.com/topics/opengl_tutorial.
3. known problem? Yes
[1] Due to my positive testing of covid, i've been not able to access campus to the code has not been tested under my Apple M1 env. I'll submit a later zip file after I've been able to access a windows notebook within 24h.
4. Extra credits? No.
5. it's so difficult..